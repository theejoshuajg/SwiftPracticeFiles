import Foundation

enum Difficulty {
    case easy, medium, hard
}

// Function to generate a random number between a given range based on difficulty
func generateRandomNumber(for difficulty: Difficulty) -> Int {
    switch difficulty {
        case .easy:
            return Int.random(in: 1...50)
        case .medium:
            return Int.random(in: 1...100)
        case .hard:
            return Int.random(in: 1...200)
    }
}

// Function to check if the guess is correct or not
func checkGuess(_ guess: Int, for target: Int) -> String {
    if guess == target {
        return "Congratulations! You guessed it right!"
    } else if guess < target {
        return "Try guessing higher."
    } else {
        return "Try guessing lower."
    }
}

// Function to validate user input within a specified range
func getUserInput(within range: ClosedRange<Int>) -> Int? {
    guard let userInput = readLine(), let userGuess = Int(userInput), range.contains(userGuess) else {
        print("Invalid input. Please enter a valid number within the range \(range).")
        return nil
    }
    return userGuess
}

// Function to calculate score based on difficulty and attempts
func calculateScore(for difficulty: Difficulty, attempts: Int) -> Int {
    let baseScore: Int
    switch difficulty {
        case .easy:
            baseScore = 50
        case .medium:
            baseScore = 100
        case .hard:
            baseScore = 200
    }
    return baseScore - attempts
}

// Function to provide hints based on the difference between the guess and the target number
func provideHint(_ guess: Int, target: Int) -> String {
    let difference = abs(guess - target)
    switch difference {
        case 1...10:
            return "You're very close!"
        case 11...20:
            return "You're getting warmer."
        case 21...50:
            return "You're warm, but not quite there yet."
        default:
            return "You're quite far from the target."
    }
}

// Main game loop
func startGame(difficulty: Difficulty) {
    let targetNumber = generateRandomNumber(for: difficulty)
    var attempts = 0
    var isGameOver = false
    
    print("Welcome to the Number Guessing Game!")
    print("I have chosen a number. Can you guess it?")
    
    while !isGameOver {
        attempts += 1
        
        print("Attempt #\(attempts): Enter your guess:")
        if let userGuess = getUserInput(within: 1...200) {
            let result = checkGuess(userGuess, for: targetNumber)
            print(result)
            
            if userGuess == targetNumber {
                let score = calculateScore(for: difficulty, attempts: attempts)
                print("Your final score is: \(score)")
                isGameOver = true
            } else {
                let hint = provideHint(userGuess, target: targetNumber)
                print(hint)
            }
        }
    }
    
    print("It took you \(attempts) attempts to guess the number \(targetNumber).")
    print("Do you want to play again? (yes/no)")
    if let playAgain = readLine(), playAgain.lowercased() == "yes" {
        startGame(difficulty: difficulty)
    } else {
        print("Thank you for playing!")
    }
}

startGame(difficulty: .medium)
